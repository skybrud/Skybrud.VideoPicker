﻿angular.module('umbraco').controller('SkybrudVideoPicker.VideosEditor.Controller', function ($scope) {

});